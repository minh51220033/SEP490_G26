package com.cvdcms.controller;

import com.cvdcms.DTO.MedicationDTO;
import com.cvdcms.entity.User;
import com.cvdcms.repository.UserRepository;
import com.cvdcms.service.MedicationService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.UUID;

@Slf4j
@Controller
@RequestMapping("/admin/medications")
@RequiredArgsConstructor
public class AdminMedicationController {

    private static final String LIST_VIEW       = "admin/medications/list";
    private static final String REDIRECT_LIST   = "redirect:/admin/medications";
    private static final String DELETE_TOKEN_KEY = "medicationDeleteToken";

    private final MedicationService medicationService;
    private final UserRepository    userRepository;

    // ── 1. DANH SÁCH ─────────────────────────────────────────────────────────
    @GetMapping
    public String list(@RequestParam(value = "q", required = false, defaultValue = "") String keyword,
                       @RequestParam(value = "active", required = false) Boolean active,
                       @RequestParam(value = "page", defaultValue = "0") int page,
                       @RequestParam(value = "size", defaultValue = "15") int size,
                       Model model, HttpSession session) {
        int safePage = Math.max(page, 0);
        int safeSize = (size == 10 || size == 15 || size == 30 || size == 50) ? size : 15;
        Pageable pageable = PageRequest.of(safePage, safeSize, Sort.by(Sort.Direction.ASC, "drugName"));
        Page<MedicationDTO> medPage = medicationService.searchMedicationsPage(keyword, active, pageable);
        List<MedicationDTO> medications = medPage != null
                ? medPage.getContent()
                : (keyword.isBlank() ? medicationService.getAllMedications() : medicationService.searchMedications(keyword));

        addLayoutAttributes(session, model);
        generateDeleteToken(session, model);
        model.addAttribute("medications", medications);
        model.addAttribute("currentPage", medPage != null ? medPage.getNumber() : 0);
        model.addAttribute("totalPages", medPage != null ? medPage.getTotalPages() : 1);
        model.addAttribute("totalItems", medPage != null ? medPage.getTotalElements() : medications.size());
        model.addAttribute("size", safeSize);
        model.addAttribute("selectedActive", active);
        model.addAttribute("keyword", keyword);
        model.addAttribute("pageTitle", "Quản lý danh mục - Danh mục thuốc");
        model.addAttribute("activeMenu", "catalogs");
        model.addAttribute("activeTab", "medications");
        return LIST_VIEW;
    }

    // ── 2. THÊM MỚI ──────────────────────────────────────────────────────────
    @PostMapping("/create")
    public String create(@ModelAttribute MedicationDTO dto, RedirectAttributes ra) {
        try {
            medicationService.createMedication(dto);
            ra.addFlashAttribute("successMessage", "Đã thêm thuốc '" + dto.getDrugName() + "' thành công.");
        } catch (DataIntegrityViolationException e) {
            // Gửi request lặp / bấm lưu nhiều lần: ràng buộc UNIQUE chặn bản ghi trùng, transaction đã rollback.
            log.warn("Trùng dữ liệu khi thêm thuốc {}: {}", dto.getDrugCode(), e.getMostSpecificCause().getMessage());
            ra.addFlashAttribute("errorMessage", "Mã thuốc hoặc mã hàng kho đã tồn tại (có thể do gửi yêu cầu lặp). Không có dữ liệu nào bị thay đổi.");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("errorMessage", e.getMessage());
        } catch (Exception e) {
            log.error("Lỗi khi thêm thuốc: ", e);
            ra.addFlashAttribute("errorMessage", "Không thể thêm thuốc: " + e.getMessage());
        }
        return REDIRECT_LIST;
    }

    // ── 3. CẬP NHẬT ──────────────────────────────────────────────────────────
    @PostMapping("/{id}/update")
    public String update(@PathVariable Long id, @ModelAttribute MedicationDTO dto, RedirectAttributes ra) {
        try {
            medicationService.updateMedication(id, dto);
            ra.addFlashAttribute("successMessage", "Đã cập nhật thuốc thành công.");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("errorMessage", e.getMessage());
        } catch (Exception e) {
            log.error("Lỗi khi cập nhật thuốc: ", e);
            ra.addFlashAttribute("errorMessage", "Không thể cập nhật thuốc: " + e.getMessage());
        }
        return REDIRECT_LIST;
    }

    // ── 4. BẬT / TẮT ─────────────────────────────────────────────────────────
    @PostMapping("/{id}/toggle")
    public String toggle(@PathVariable Long id, RedirectAttributes ra) {
        try {
            medicationService.toggleMedicationStatus(id);
            ra.addFlashAttribute("successMessage", "Đã thay đổi trạng thái thuốc.");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("errorMessage", e.getMessage());
        } catch (Exception e) {
            log.error("Lỗi khi thay đổi trạng thái thuốc: ", e);
            ra.addFlashAttribute("errorMessage", "Không thể thay đổi trạng thái thuốc: " + e.getMessage());
        }
        return REDIRECT_LIST;
    }

    // ── 5. XÓA ───────────────────────────────────────────────────────────────
    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id,
                         @RequestParam(required = false) String deleteToken,
                         HttpSession session, RedirectAttributes ra) {
        try {
            requireDeletePermission(session, deleteToken);
            medicationService.deleteMedication(id);
            ra.addFlashAttribute("successMessage", "Đã xóa thuốc thành công.");
        } catch (ResponseStatusException e) {
            ra.addFlashAttribute("errorMessage", e.getReason());
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("errorMessage", e.getMessage());
        } catch (Exception e) {
            log.error("Lỗi khi xóa thuốc: ", e);
            ra.addFlashAttribute("errorMessage", "Không thể xóa thuốc: " + e.getMessage());
        }
        return REDIRECT_LIST;
    }

    // ── helpers ───────────────────────────────────────────────────────────────
    private void requireDeletePermission(HttpSession session, String deleteToken) {
        Object sessionUser = session.getAttribute("loggedInUser");
        if (!(sessionUser instanceof User user)
                || user.getUserId() == null
                || (!userRepository.hasActiveAdminRole(user.getUserId()) && !userRepository.hasActivePermission(user.getUserId(), "CATALOG_MANAGE"))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Chỉ Admin đang hoạt động mới được xóa thuốc.");
        }
        if (deleteToken == null || !deleteToken.equals(session.getAttribute(DELETE_TOKEN_KEY))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Phiên xác nhận không hợp lệ. Vui lòng tải lại trang.");
        }
    }

    private void generateDeleteToken(HttpSession session, Model model) {
        synchronized (session) {
            if (!(session.getAttribute(DELETE_TOKEN_KEY) instanceof String)) {
                session.setAttribute(DELETE_TOKEN_KEY, UUID.randomUUID().toString());
            }
            model.addAttribute("deleteToken", session.getAttribute(DELETE_TOKEN_KEY));
        }
    }

    private void addLayoutAttributes(HttpSession session, Model model) {
        model.addAttribute("roleNames", session.getAttribute("roleNames"));
        Object sessionUser = session.getAttribute("loggedInUser");
        if (sessionUser instanceof User user) {
            model.addAttribute("displayName", user.getUsername());
        }
    }
}
