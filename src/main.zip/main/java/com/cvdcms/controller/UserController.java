package com.cvdcms.controller;

import com.cvdcms.DTO.UserRegisterDTO;
import com.cvdcms.entity.*;
import com.cvdcms.entity.enums.TokenType;
import com.cvdcms.repository.RoleRepository;
import com.cvdcms.repository.StaffProfileRepository;
import com.cvdcms.repository.TokenRepository;
import com.cvdcms.repository.UserRepository;
import com.cvdcms.repository.PatientProfileRepository;
import com.cvdcms.service.EmailService;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;

@Controller
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private TokenRepository tokenRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private PatientProfileRepository patientProfileRepository;

    @Autowired
    private StaffProfileRepository staffProfileRepository;

    @Autowired(required = false)
    private com.cvdcms.service.CustomerPortalService customerPortalService;

    @Autowired(required = false)
    private com.cvdcms.service.ServiceCatalogService serviceCatalogService;

    private Branch resolveUserPortalBranch(HttpSession session, List<Branch> activeBranches) {
        if (session == null) {
            return null;
        }
        if (session.getAttribute("loggedInUser") instanceof User sessionUser && sessionUser.getUserId() != null) {
            PatientProfile defaultProfile = patientProfileRepository
                    .findFirstByUser_UserIdAndIsDefaultTrue(sessionUser.getUserId())
                    .orElse(null);
            if (defaultProfile != null
                    && defaultProfile.getPreferredBranch() != null
                    && Boolean.TRUE.equals(defaultProfile.getPreferredBranch().getIsActive())) {
                return defaultProfile.getPreferredBranch();
            }
            User dbUser = userRepository.findById(sessionUser.getUserId()).orElse(sessionUser);
            if (dbUser != null && dbUser.getBranch() != null && Boolean.TRUE.equals(dbUser.getBranch().getIsActive())) {
                return dbUser.getBranch();
            }
        }
        Object selectedBranchIdObj = session.getAttribute("selectedPortalBranchId");
        if (selectedBranchIdObj instanceof Long selectedId && activeBranches != null) {
            for (Branch b : activeBranches) {
                if (selectedId.equals(b.getBranchId())) {
                    return b;
                }
            }
        }
        return null;
    }

    private String populateCustomerPortalHome(Model model) {
        return populateCustomerPortalHome(model, null);
    }

    private String populateCustomerPortalHome(Model model, HttpSession session) {
        model.addAttribute("activeNav", "home");
        if (customerPortalService != null) {
            List<Branch> branches = customerPortalService.getActiveBranches();
            Branch currentBranch = resolveUserPortalBranch(session, branches);
            Long targetBranchId = currentBranch != null ? currentBranch.getBranchId() : null;

            boolean isLoggedIn = session != null && session.getAttribute("loggedInUser") != null;
            String effectivePhone = "0987654321";
            if (isLoggedIn || currentBranch != null) {
                Branch phoneBranch = currentBranch != null ? currentBranch : customerPortalService.getPrimaryBranch();
                if (phoneBranch != null && phoneBranch.getPhone() != null && !phoneBranch.getPhone().isBlank()) {
                    effectivePhone = phoneBranch.getPhone().trim();
                }
            }

            List<Service> allPortalServices = customerPortalService.getFeaturedServices(30);
            List<Service> topFeatured = allPortalServices.size() <= 5
                    ? allPortalServices
                    : allPortalServices.subList(0, 5);

            model.addAttribute("currentPortalBranch", currentBranch);
            model.addAttribute("effectiveContactPhone", effectivePhone);
            model.addAttribute("categories", serviceCatalogService != null ? serviceCatalogService.getActiveCategories() : List.of());
            model.addAttribute("portalServices", allPortalServices);
            model.addAttribute("featuredServices", topFeatured);
            model.addAttribute("servicePromotions", customerPortalService.getActiveServicePromotionsMap(targetBranchId));
            model.addAttribute("featuredDoctors", customerPortalService.getFeaturedDoctors(4, targetBranchId));
            model.addAttribute("allDoctors", customerPortalService.getPublicDoctors(null, null, null));
            model.addAttribute("latestNews", customerPortalService.getLatestPublishedNews(4, targetBranchId));
            model.addAttribute("branches", branches);
        } else {
            model.addAttribute("currentPortalBranch", null);
            model.addAttribute("effectiveContactPhone", "0987654321");
            model.addAttribute("categories", List.of());
            model.addAttribute("portalServices", List.of());
            model.addAttribute("featuredServices", List.of());
            model.addAttribute("servicePromotions", java.util.Map.of());
            model.addAttribute("featuredDoctors", List.of());
            model.addAttribute("allDoctors", List.of());
            model.addAttribute("latestNews", List.of());
            model.addAttribute("branches", List.of());
        }
        return "portal/home";
    }

    private boolean hasStaffRole(List<String> roleNames) {
        if (roleNames == null) {
            return false;
        }
        for (String r : roleNames) {
            if (r == null) continue;
            String norm = r.trim().toUpperCase(Locale.ROOT);
            if ("ADMIN".equals(norm) || "ROLE_ADMIN".equals(norm)
                    || "BAC_SI".equals(norm) || "ROLE_BAC_SI".equals(norm)
                    || "LE_TAN".equals(norm) || "ROLE_LE_TAN".equals(norm)
                    || "QUAN_LY_KHO".equals(norm) || "ROLE_QUAN_LY_KHO".equals(norm)
                    || "KE_TOAN".equals(norm) || "ROLE_KE_TOAN".equals(norm)) {
                return true;
            }
        }
        return false;
    }

    // =====================================================
    // BIỂU THỨC KIỂM TRA DỮ LIỆU ĐẦU VÀO
    // =====================================================

    // Username: 4–50 ký tự, bắt đầu bằng chữ hoặc số.
    // Cho phép chữ cái, chữ số, dấu chấm, gạch dưới và gạch ngang.
    private static final Pattern USERNAME_PATTERN =
            Pattern.compile("^[A-Za-z0-9][A-Za-z0-9._-]{3,49}$");

    // Email: kiểm tra cấu trúc cơ bản và phần tên miền.
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile(
                    "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
            );

    // Số điện thoại Việt Nam: bắt đầu bằng 0, tổng cộng 10 hoặc 11 chữ số.
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^0\\d{9,10}$");

    // OTP: chính xác 6 chữ số.
    private static final Pattern OTP_PATTERN =
            Pattern.compile("^\\d{6}$");

    // =====================================================
    // QUẢN LÝ VÒNG ĐỜI REFRESH TOKEN (TokenType.REFRESH)
    // =====================================================

    private Token issueNewRefreshToken(User user, HttpSession session) {
        if (user == null || user.getUserId() == null) {
            return null;
        }
        // Thu hồi các Refresh Token cũ chưa sử dụng của tài khoản này
        List<Token> activeRefreshTokens = tokenRepository
                .findByUser_UserIdAndTokenTypeAndIsUsedFalseOrderByCreatedAtDesc(
                        user.getUserId(), TokenType.REFRESH);
        for (Token oldToken : activeRefreshTokens) {
            oldToken.setIsUsed(true);
        }
        if (!activeRefreshTokens.isEmpty()) {
            tokenRepository.saveAll(activeRefreshTokens);
        }

        // Cấp phát Refresh Token mới có thời hạn 24 giờ (chuẩn bảo mật hệ thống y tế)
        Token refreshToken = new Token();
        refreshToken.setToken(UUID.randomUUID().toString());
        refreshToken.setTokenType(TokenType.REFRESH);
        refreshToken.setIsUsed(false);
        refreshToken.setExpiryDate(LocalDateTime.now().plusHours(24));
        refreshToken.setUser(user);
        Token savedToken = tokenRepository.save(refreshToken);

        if (session != null) {
            session.setAttribute("refreshToken", savedToken.getToken());
            session.setAttribute("refreshTokenExpiry", savedToken.getExpiryDate());
        }
        return savedToken;
    }

    private void revokeAllRefreshTokens(User user) {
        if (user == null || user.getUserId() == null) {
            return;
        }
        List<Token> activeRefreshTokens = tokenRepository
                .findByUser_UserIdAndTokenTypeAndIsUsedFalseOrderByCreatedAtDesc(
                        user.getUserId(), TokenType.REFRESH);
        for (Token t : activeRefreshTokens) {
            t.setIsUsed(true);
        }
        if (!activeRefreshTokens.isEmpty()) {
            tokenRepository.saveAll(activeRefreshTokens);
        }
    }

    // =====================================================
    // CHE EMAIL
    // =====================================================

    private String maskEmail(String email) {

        if (email == null || !email.contains("@")) {
            return "";
        }

        int atIndex = email.indexOf("@");

        String prefix = email.substring(0, atIndex);
        String domain = email.substring(atIndex);

        if (prefix.length() <= 2) {
            return prefix.charAt(0) + "****" + domain;
        }

        return prefix.substring(0, 2)
                + "********"
                + domain;
    }



    @GetMapping({"/", "/portal"})
    public String customerPortalLanding(HttpSession session, Model model) {
        Object loggedInUser = session != null ? session.getAttribute("loggedInUser") : null;
        if (loggedInUser instanceof User sessionUser && sessionUser.getUserId() != null) {
            User user = userRepository.findById(sessionUser.getUserId()).orElse(null);
            if (user != null && Boolean.TRUE.equals(user.getIsActive())) {
                session.setAttribute("loggedInUser", user);
                List<String> roleNames = user.getRoles() != null
                        ? user.getRoles().stream().map(Role::getRoleName).toList()
                        : List.of();
                session.setAttribute("roleNames", roleNames);
                model.addAttribute("roleNames", roleNames);
                PatientProfile defaultProfile = patientProfileRepository
                        .findFirstByUser_UserIdAndIsDefaultTrue(user.getUserId())
                        .orElse(null);
                if (defaultProfile != null) {
                    model.addAttribute("defaultPatientProfile", defaultProfile);
                    session.setAttribute("defaultPatientProfile", defaultProfile);
                }
            }
        }
        return populateCustomerPortalHome(model, session);
    }


    @GetMapping("/home")
    public String home(@RequestParam(value = "view", required = false) String view, HttpSession session, Model model) {
        if (session == null || !(session.getAttribute("loggedInUser") instanceof User)) {
            return populateCustomerPortalHome(model);
        }

        // 1. Kiểm tra người dùng đã đăng nhập chưa
        Object loggedInUser = session.getAttribute("loggedInUser");

        if (!(loggedInUser instanceof User)) {
            return "redirect:/login";
        }

        User sessionUser = (User) loggedInUser;

        // 2. Lấy thông tin tài khoản mới nhất từ database
        User user = userRepository.findById(sessionUser.getUserId())
                .orElse(null);

        if (user == null || !Boolean.TRUE.equals(user.getIsActive())) {
            session.invalidate();
            return "redirect:/login";
        }

        // Kiểm tra vai trò của tài khoản có đang hoạt động hay không
        boolean hasActiveRole = user.getRoles() != null && user.getRoles().stream()
                .anyMatch(r -> r != null && Boolean.TRUE.equals(r.getIsActive()));
        if (!hasActiveRole && !isAdmin(user)) {
            session.invalidate();
            return "redirect:/login";
        }

        // Cập nhật tài khoản mới nhất vào session
        session.setAttribute("loggedInUser", user);
        session.setAttribute("username", user.getUsername());

        // 3. Lấy danh sách vai trò và tập quyền tĩnh của tài khoản
        List<String> roleNames = user.getRoles()
                .stream()
                .map(Role::getRoleName)
                .toList();
        List<String> permissionCodes = userRepository.findActivePermissionCodesByUserId(user.getUserId());

        session.setAttribute("roleNames", roleNames);
        session.setAttribute("permissionCodes", permissionCodes);
        model.addAttribute("roleNames", roleNames);
        model.addAttribute("permissionCodes", permissionCodes);
        boolean isAdmin = userRepository.hasActiveAdminRole(user.getUserId());
        session.setAttribute("isAdmin", isAdmin);
        model.addAttribute("isAdmin", isAdmin);

        // 4. Tên hiển thị mặc định là username
        String displayName = user.getUsername();

        // 5. Khởi tạo giá trị mặc định cho hồ sơ và cơ sở
        model.addAttribute("defaultPatientProfile", null);
        String currentBranchName = user.getBranch() != null && user.getBranch().getBranchName() != null
                ? user.getBranch().getBranchName()
                : "Chưa xác định cơ sở";
        String currentBranchAddress = user.getBranch() != null && user.getBranch().getAddress() != null
                ? user.getBranch().getAddress()
                : "";

        // 6. Nếu là nhân sự/bác sĩ/admin có hồ sơ nhân sự, ưu tiên lấy tên nhân sự
        StaffProfile staffProfile = staffProfileRepository.findByUser_UserId(user.getUserId()).orElse(null);
        if (staffProfile != null && staffProfile.getFullName() != null && !staffProfile.getFullName().isBlank()) {
            displayName = staffProfile.getFullName();
        }

        // 7. Tìm hồ sơ bệnh nhân mặc định của tài khoản
        PatientProfile defaultProfile =
                patientProfileRepository
                        .findFirstByUser_UserIdAndIsDefaultTrue(user.getUserId())
                        .orElse(null);

        if (defaultProfile != null) {

            // Truyền hồ sơ mặc định sang HTML để lấy avatarUrl
            model.addAttribute("defaultPatientProfile", defaultProfile);
            session.setAttribute("defaultPatientProfile", defaultProfile);

            // Nếu có họ tên, dùng họ tên làm tên hiển thị
            if (defaultProfile.getFullName() != null
                    && !defaultProfile.getFullName().isBlank()) {
                displayName = defaultProfile.getFullName();
            }

            // Lấy cơ sở ưu tiên từ hồ sơ mặc định
            Branch branch = defaultProfile.getPreferredBranch();

            if (branch != null) {

                if (branch.getBranchName() != null
                        && !branch.getBranchName().isBlank()) {
                    currentBranchName = branch.getBranchName();
                }

                if (branch.getAddress() != null
                        && !branch.getAddress().isBlank()) {
                    currentBranchAddress = branch.getAddress();
                }
            }
        }

        model.addAttribute("displayName", displayName);
        model.addAttribute("currentBranchName", currentBranchName);
        model.addAttribute("currentBranchAddress", currentBranchAddress);
        session.setAttribute("displayName", displayName);
        session.setAttribute("currentBranchName", currentBranchName);

        if (!hasStaffRole(roleNames) || "portal".equalsIgnoreCase(view)) {
            return populateCustomerPortalHome(model);
        }
        return "user/home";
    }

    // =====================================================
    // LOGIN - GET
    // =====================================================

    @GetMapping("/login")
    public String showLoginForm(
            HttpSession session,
            Model model) {

        Object notification =
                session.getAttribute("notification");

        if (notification != null) {

            model.addAttribute(
                    "notification",
                    notification
            );

            session.removeAttribute("notification");
        }

        return "user/login";
    }


    // =====================================================
    // LOGIN - POST
    // =====================================================

    @PostMapping("/login")
    public String processLogin(
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            HttpSession session,
            Model model) {

        // ---------------------------------------------
        // USERNAME
        // ---------------------------------------------

        username = username == null
                ? ""
                : username.trim();


        // ---------------------------------------------
        // CHECK INPUT
        // ---------------------------------------------

        if (username.isEmpty() ||
                password == null ||
                password.isEmpty()) {

            model.addAttribute(
                    "error",
                    "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu."
            );

            return "user/login";
        }


        // ---------------------------------------------
        // FIND USER
        // ---------------------------------------------

        Optional<User> userOpt =
                userRepository.findByUsername(username);


        // ---------------------------------------------
        // USER NOT FOUND
        // ---------------------------------------------

        if (userOpt.isEmpty()) {

            model.addAttribute(
                    "error",
                    "Tên đăng nhập hoặc mật khẩu không đúng!"
            );

            return "user/login";
        }


        User user = userOpt.get();


        // ---------------------------------------------
        // CHECK ACTIVE
        // ---------------------------------------------

        if (user.getIsActive() == null ||
                !user.getIsActive()) {

            model.addAttribute(
                    "error",
                    "Tài khoản của bạn đã bị khóa. Vui lòng liên hệ quản trị viên."
            );

            return "user/login";
        }

        // ---------------------------------------------
        // CHECK ROLE ACTIVE (Chặn tài khoản thuộc vai trò đã bị ngừng hoạt động)
        // ---------------------------------------------
        boolean hasActiveRole = false;
        String inactiveRoleName = null;

        if (user.getRoles() != null && !user.getRoles().isEmpty()) {
            for (Role r : user.getRoles()) {
                if (r != null) {
                    if (Boolean.TRUE.equals(r.getIsActive())) {
                        hasActiveRole = true;
                        break;
                    } else if (inactiveRoleName == null) {
                        inactiveRoleName = r.getDisplayName() != null ? r.getDisplayName() : r.getRoleName();
                    }
                }
            }
        }

        if (!hasActiveRole && !isAdmin(user)) {
            String roleMsg = (inactiveRoleName != null)
                    ? "Vai trò của bạn (" + inactiveRoleName + ") đã bị tạm ngưng hoạt động trên toàn hệ thống. Vui lòng liên hệ Quản trị viên."
                    : "Tài khoản của bạn chưa được kích hoạt vai trò hợp lệ. Vui lòng liên hệ Quản trị viên.";
            model.addAttribute("error", roleMsg);
            return "user/login";
        }


        // ---------------------------------------------
        // CHECK PASSWORD - BCrypt
        // ---------------------------------------------

        if (!passwordEncoder.matches(
                password,
                user.getPassword())) {

            model.addAttribute(
                    "error",
                    "Tên đăng nhập hoặc mật khẩu không đúng!"
            );

            return "user/login";
        }



        // =============================================
        // ĐĂNG NHẬP THÀNH CÔNG
        // =============================================

        // Ghi nhận thời điểm đăng nhập gần nhất.
        user.setLastLoginAt(LocalDateTime.now());
        user = userRepository.save(user);

        session.setAttribute("loggedInUser", user);
        session.setAttribute("username", user.getUsername());

        // Cấp phát Refresh Token mới cho phiên đăng nhập
        issueNewRefreshToken(user, session);

        // Lưu tên các vai trò và tập quyền tĩnh vào session.
        session.setAttribute(
                "roleNames",
                user.getRoles()
                        .stream()
                        .map(Role::getRoleName)
                        .toList()
        );
        session.setAttribute(
                "permissionCodes",
                userRepository.findActivePermissionCodesByUserId(user.getUserId())
        );
        session.setAttribute(
                "isAdmin",
                userRepository.hasActiveAdminRole(user.getUserId())
        );

        // Hồ sơ bệnh nhân chỉ là điều kiện vào portal của tài khoản bệnh nhân.
        if (user.getRoles().stream().noneMatch(role ->
                "BENH_NHAN".equalsIgnoreCase(role.getRoleName()))) {
            return "redirect:/home";
        }

        // =============================================
        // KIỂM TRA HỒ SƠ CƠ BẢN CHO TÀI KHOẢN BỆNH NHÂN
        // =============================================

        boolean hasDefaultProfile =
                patientProfileRepository
                        .existsByUser_UserIdAndIsDefaultTrue(
                                user.getUserId()
                        );

        if (!hasDefaultProfile) {
            return "redirect:/profile/complete";
        }

        // Đã có hồ sơ mặc định thì vào trang chính.
        return "redirect:/home";

    }

    // =====================================================
    // REGISTER - GET
    // =====================================================

    @GetMapping("/register")
    public String showRegisterForm(Model model) {

        model.addAttribute(
                "registerDTO",
                new UserRegisterDTO()
        );

        return "user/register";
    }


    // =====================================================
    // REGISTER - POST
    // =====================================================

    @PostMapping("/register")
    public String processRegister(
            @ModelAttribute("registerDTO")
            UserRegisterDTO dto,
            Model model,
            HttpSession session) {

        // -----------------------------
        // USERNAME
        // -----------------------------

        // Chuẩn hóa username, không cho phép giá trị null.
        String username = dto.getUsername() == null
                ? ""
                : dto.getUsername().trim();

        // Kiểm tra bắt buộc và định dạng username.
        if (!USERNAME_PATTERN.matcher(username).matches()) {
            model.addAttribute(
                    "error",
                    "Tên đăng nhập phải từ 4 đến 50 ký tự, "
                            + "bắt đầu bằng chữ hoặc số và chỉ chứa "
                            + "chữ cái, chữ số, dấu chấm, gạch dưới "
                            + "hoặc gạch ngang."
            );

            model.addAttribute("registerDTO", dto);
            return "user/register";
        }

        // Kiểm tra username đã tồn tại.
        if (userRepository.findByUsername(username).isPresent()) {
            model.addAttribute(
                    "error",
                    "Tên đăng nhập đã tồn tại. Vui lòng chọn tên khác."
            );

            model.addAttribute("registerDTO", dto);
            return "user/register";
        }


        // -----------------------------
        // PASSWORD
        // -----------------------------

        String password = dto.getPassword();

        if (password == null ||
                password.length() < 8 ||
                password.length() > 64) {

            model.addAttribute(
                    "error",
                    "Mật khẩu phải từ 8 đến 64 ký tự."
            );

            return "user/register";
        }


        // -----------------------------
        // CONFIRM PASSWORD
        // -----------------------------

        String confirmPassword =
                dto.getConfirmPassword();

        if (!password.equals(confirmPassword)) {

            model.addAttribute(
                    "error",
                    "Mật khẩu xác minh không khớp."
            );

            return "user/register";
        }


        // -----------------------------
        // EMAIL
        // -----------------------------
        String email = dto.getEmail() == null
                ? ""
                : dto.getEmail().trim().toLowerCase(Locale.ROOT);

        if (email.isEmpty()
                || email.length() > 254
                || !EMAIL_PATTERN.matcher(email).matches()) {

            model.addAttribute("error", "Email không hợp lệ.");
            model.addAttribute("registerDTO", dto);
            return "user/register";
        }

        // -----------------------------
        // PHONE
        // -----------------------------
        String phoneNumber = dto.getPhoneNumber() == null
                ? ""
                : dto.getPhoneNumber().trim();

        if (!PHONE_PATTERN.matcher(phoneNumber).matches()) {
            model.addAttribute(
                    "error",
                    "Số điện thoại phải bắt đầu bằng số 0 "
                            + "và gồm 10 hoặc 11 chữ số."
            );

            model.addAttribute("registerDTO", dto);
            return "user/register";
        }

        // -----------------------------
        // KIỂM TRA TRÙNG DỮ LIỆU
        // -----------------------------
        if (userRepository.existsByEmail(email)) {
            model.addAttribute(
                    "error",
                    "Email đã được sử dụng. Vui lòng nhập email khác."
            );

            model.addAttribute("registerDTO", dto);
            return "user/register";
        }

        if (userRepository.existsByPhoneNumber(phoneNumber)) {
            model.addAttribute(
                    "error",
                    "Số điện thoại đã được sử dụng. Vui lòng nhập số khác."
            );

            model.addAttribute("registerDTO", dto);
            return "user/register";
        }

        // =============================================
        // LẤY VAI TRÒ BỆNH NHÂN
        // =============================================

        Role patientRole = roleRepository.findById(6)
                .orElse(null);

        // ID role thay đổi giữa các bộ seed; xác định vai trò bằng mã nghiệp vụ.
        if (patientRole == null || !"BENH_NHAN".equalsIgnoreCase(patientRole.getRoleName())) {
            patientRole = roleRepository.findByRoleName("BENH_NHAN").orElse(null);
        }

        if (patientRole == null
                || !Boolean.TRUE.equals(patientRole.getIsActive())) {

            model.addAttribute(
                    "error",
                    "Vai trò bệnh nhân chưa được cấu hình hoặc đang bị khóa."
            );
            model.addAttribute("registerDTO", dto);
            return "user/register";
        }

        // =============================================
        // TẠO TÀI KHOẢN
        // =============================================

        User user = new User();

        user.setUsername(username);

        // Mật khẩu luôn được mã hóa bằng BCrypt.
        user.setPassword(passwordEncoder.encode(password));

        user.setEmail(email);
        user.setPhoneNumber(phoneNumber);
        user.setIsActive(true);
        user.setStatus("ACTIVE");
        user.setUserType(com.cvdcms.entity.enums.UserType.PATIENT);
        user.setLastLoginAt(LocalDateTime.now());

        user.getRoles().add(patientRole);

        user = userRepository.save(user);

        // =============================================
        // ĐĂNG NHẬP NGAY SAU KHI ĐĂNG KÝ
        // =============================================

        session.setAttribute("loggedInUser", user);
        session.setAttribute("username", user.getUsername());

        issueNewRefreshToken(user, session);

        List<String> roleNames = user.getRoles()
                .stream()
                .map(Role::getRoleName)
                .toList();

        session.setAttribute("roleNames", roleNames);
        session.setAttribute(
                "permissionCodes",
                userRepository.findActivePermissionCodesByUserId(user.getUserId())
        );

        session.setAttribute(
                "notification",
                "Đăng ký tài khoản thành công. Vui lòng hoàn thiện hồ sơ."
        );

        // URL này cần khớp với @GetMapping trong ProfileController.
        return "redirect:/profile/complete";

    }


    // =====================================================
    // FORGOT PASSWORD - GET
    // =====================================================

    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {

        return "user/forgot-password";
    }


    // =====================================================
    // FORGOT PASSWORD - POST
    // =====================================================

    @PostMapping("/forgot-password")
    public String processForgotPassword(
            @RequestParam("username") String username,
            HttpSession session,
            Model model) {

        username = username == null
                ? ""
                : username.trim();

        if (username.isEmpty()) {

            model.addAttribute(
                    "error",
                    "Vui lòng nhập tên đăng nhập."
            );

            return "user/forgot-password";
        }


        Optional<User> userOpt =
                userRepository.findByUsername(username);

        if (userOpt.isEmpty()) {

            model.addAttribute(
                    "error",
                    "Nếu tài khoản tồn tại, hệ thống sẽ gửi mã OTP đến email đã đăng ký."
            );

            return "user/forgot-password";
        }


        User user = userOpt.get();

        String email = user.getEmail();


        if (email == null || email.isBlank()) {

            model.addAttribute(
                    "error",
                    "Nếu tài khoản tồn tại, hệ thống sẽ gửi mã OTP đến email đã đăng ký."
            );

            return "user/forgot-password";
        }


        // =================================================
        // TẠO OTP BẰNG SECURE RANDOM
        // =================================================

        SecureRandom secureRandom =
                new SecureRandom();

        int otpNumber =
                secureRandom.nextInt(1_000_000);

        String otp =
                String.format(
                        "%06d",
                        otpNumber
                );


        // =================================================
        // TẠO TOKEN
        // =================================================

        Token resetToken = new Token();

        resetToken.setToken(otp);
        resetToken.setTokenType(TokenType.OTP);
        resetToken.setIsUsed(false);

        resetToken.setExpiryDate(
                LocalDateTime.now()
                        .plusMinutes(5)
        );

        resetToken.setUser(user);

        tokenRepository.save(resetToken);


        // =================================================
        // GỬI EMAIL
        // =================================================

        String emailContent =
                "Xin chào,\n\n"
                        + "Bạn vừa yêu cầu đặt lại mật khẩu cho tài khoản: "
                        + username
                        + "\n\n"
                        + "Mã OTP của bạn là: "
                        + otp
                        + "\n\n"
                        + "Mã OTP có hiệu lực trong 5 phút "
                        + "và chỉ được sử dụng một lần.\n\n"
                        + "Nếu bạn không thực hiện yêu cầu này, "
                        + "vui lòng bỏ qua email này.\n\n"
                        + "Trân trọng,\n"
                        + "CV-DCMS";


        try {
            emailService.sendSimpleMail(
                    email,
                    "CV-DCMS - Mã OTP đặt lại mật khẩu",
                    emailContent
            );
        } catch (Exception e) {
            System.err.println("[OTP ERROR] Không thể gửi email qua SMTP: " + e.getMessage());
            System.out.println("==================================================================");
            System.out.println(">>> [OTP TEST / DEV FALLBACK] Mã OTP cho tài khoản [" + username + "] là: " + otp);
            System.out.println("==================================================================");
            session.setAttribute("otpDevHint", "Hệ thống chưa kết nối được máy chủ gửi mail SMTP. Mã OTP cho tài khoản của bạn là: " + otp);
        }


        // =================================================
        // LƯU THÔNG TIN RESET VÀO SESSION
        // =================================================

        session.setAttribute(
                "resetUsername",
                username
        );

        session.setAttribute(
                "maskedEmail",
                maskEmail(email)
        );


        return "redirect:/verify-otp";
    }


    // =====================================================
    // VERIFY OTP - GET
    // =====================================================

    @GetMapping("/verify-otp")
    public String showVerifyOtpPage(
            HttpSession session,
            Model model) {

        String username =
                (String) session
                        .getAttribute("resetUsername");

        if (username == null) {

            return "redirect:/forgot-password";
        }

        model.addAttribute(
                "maskedEmail",
                session.getAttribute("maskedEmail")
        );

        Object otpDevHint = session.getAttribute("otpDevHint");
        if (otpDevHint != null) {
            model.addAttribute("otpDevHint", otpDevHint);
            session.removeAttribute("otpDevHint");
        }

        return "user/verify-otp";
    }


    // =====================================================
    // VERIFY OTP - POST
    // =====================================================

    @PostMapping("/verify-otp")
    public String processVerifyOtp(
            @RequestParam("otp") String otp,
            HttpSession session,
            Model model) {

        String username =
                (String) session
                        .getAttribute("resetUsername");


        if (username == null) {

            return "redirect:/forgot-password";
        }


        otp = otp == null ? "" : otp.trim();

        if (!OTP_PATTERN.matcher(otp).matches()) {
            model.addAttribute("error", "Mã OTP phải gồm 6 chữ số.");
            model.addAttribute(
                    "maskedEmail",
                    session.getAttribute("maskedEmail")
            );

            return "user/verify-otp";
        }


        User user =
                userRepository
                        .findByUsername(username)
                        .orElse(null);


        if (user == null) {

            return "redirect:/forgot-password";
        }


        Optional<Token> tokenOpt =
                tokenRepository
                        .findByTokenAndUser(
                                otp,
                                user
                        );


        if (tokenOpt.isEmpty() || Boolean.TRUE.equals(tokenOpt.get().getIsUsed())) {

            model.addAttribute(
                    "error",
                    "Mã OTP không hợp lệ hoặc đã được sử dụng."
            );

            model.addAttribute(
                    "maskedEmail",
                    session.getAttribute("maskedEmail")
            );

            return "user/verify-otp";
        }


        Token token = tokenOpt.get();


        if (token.getExpiryDate() == null ||
                token.getExpiryDate()
                        .isBefore(LocalDateTime.now())) {

            tokenRepository.delete(token);

            model.addAttribute(
                    "error",
                    "Mã OTP đã hết hạn. Vui lòng yêu cầu mã mới."
            );

            model.addAttribute(
                    "maskedEmail",
                    session.getAttribute("maskedEmail")
            );

            return "user/verify-otp";
        }

        // Đánh dấu OTP đã sử dụng
        token.setIsUsed(true);
        tokenRepository.save(token);

        session.setAttribute(
                "resetVerified",
                true
        );


        return "redirect:/reset-password";
    }


    // =====================================================
    // RESET PASSWORD - GET
    // =====================================================


    @GetMapping("/reset-password")
    public String showResetPasswordPage(
            HttpSession session) {

        String username =
                (String) session
                        .getAttribute("resetUsername");

        Boolean verified =
                (Boolean) session
                        .getAttribute("resetVerified");


        if (username == null ||
                !Boolean.TRUE.equals(verified)) {

            return "redirect:/forgot-password";
        }


        return "user/reset-password";
    }


    // =====================================================
    // RESET PASSWORD - POST
    // =====================================================

    @PostMapping("/reset-password")
    public String processResetPassword(
            @RequestParam("newPassword")
            String newPassword,

            @RequestParam("confirmPassword")
            String confirmPassword,

            HttpSession session,
            Model model) {


        String username =
                (String) session
                        .getAttribute("resetUsername");

        Boolean verified =
                (Boolean) session
                        .getAttribute("resetVerified");


        if (username == null ||
                !Boolean.TRUE.equals(verified)) {

            return "redirect:/forgot-password";
        }


        // =================================================
        // PASSWORD
        // =================================================

        if (newPassword == null ||
                newPassword.length() < 8 ||
                newPassword.length() > 64) {

            model.addAttribute(
                    "error",
                    "Mật khẩu mới phải từ 8 đến 64 ký tự."
            );

            return "user/reset-password";
        }


        if (confirmPassword == null
                || !newPassword.equals(confirmPassword)) {

            model.addAttribute(
                    "error",
                    "Mật khẩu xác minh không khớp."
            );

            return "user/reset-password";
        }


        // =================================================
        // TÌM USER
        // =================================================

        User user =
                userRepository
                        .findByUsername(username)
                        .orElse(null);


        if (user == null) {

            return "redirect:/login";
        }


        // =================================================
        // ĐỔI PASSWORD & THU HỒI REFRESH TOKEN CŨ
        // =================================================

        user.setPassword(
                passwordEncoder.encode(
                        newPassword
                )
        );

        userRepository.save(user);
        revokeAllRefreshTokens(user);


        // =================================================
        // XÓA SESSION RESET
        // =================================================

        session.removeAttribute(
                "resetUsername"
        );

        session.removeAttribute(
                "maskedEmail"
        );

        session.removeAttribute(
                "resetVerified"
        );


        session.setAttribute(
                "notification",
                "Đổi mật khẩu thành công! Vui lòng đăng nhập bằng mật khẩu mới."
        );


        return "redirect:/login";
    }


    // ================= ĐĂNG XUẤT =================

    @PostMapping("/logout")
    public String logout(HttpSession session) {
        Object loggedInUser = session.getAttribute("loggedInUser");
        if (loggedInUser instanceof User user) {
            revokeAllRefreshTokens(user);
        }
        session.invalidate();

        return "redirect:/login";
    }

    private boolean isAdmin(User user) {
        if (user == null || user.getRoles() == null) {
            return false;
        }
        return user.getRoles().stream()
                .filter(Objects::nonNull)
                .map(Role::getRoleName)
                .filter(Objects::nonNull)
                .anyMatch(n -> n.equalsIgnoreCase("ADMIN") || n.equalsIgnoreCase("ROLE_ADMIN"));
    }

}
